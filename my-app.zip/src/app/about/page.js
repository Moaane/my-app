export default function Page() {
  return (
    <div className="min-h-screen flex justify-center items-center bg-red-100">
      <h1 className="text-7xl">HELLO WORLD</h1>
    </div>
  );
}
